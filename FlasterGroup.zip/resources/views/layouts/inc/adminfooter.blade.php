<footer class="footer">
    <div class="container-fluid">
      <div class="copyright float-right">
        &copy;
        <script>
          document.write(new Date().getFullYear())
        </script>, made with <i class="material-icons">favorite</i> by
        <a href="https://www.flaster.ma/" target="_blank">Flaster Group</a> for a better web.
      </div>
    </div>
  </footer>